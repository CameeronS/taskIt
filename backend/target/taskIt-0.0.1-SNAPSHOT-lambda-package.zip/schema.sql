-- Insert to role
INSERT INTO role (role_id, role_name) VALUES (1, 'ADMIN');

INSERT INTO role (role_id, role_name) VALUES (2, 'USER');